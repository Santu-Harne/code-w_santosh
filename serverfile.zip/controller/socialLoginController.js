const assert = require('assert')
const session = require('express-session')
const express = require('express')
const app = express()
const passport = require('passport');
const jwt = require('jsonwebtoken')
const { createAccessToken } = require('../util/token')
const { regToken } = require('../util/regToken')
const { StatusCodes } = require('http-status-codes')
const con = require('../db/connectionString')
const sendingMail = require('../middleware/mail')
const GoogleStrategy = require('passport-google-oauth20').Strategy;
let userProfile;
const socialLoginController = {
    googleLogin: async (req, res) => {
        try {
            passport.use(new GoogleStrategy({
                clientID: process.env.GOOGLE_CLIENT_ID,
                clientSecret: process.env.GOOGLE_CLIENT_SECRET,
                callbackURL: "http://localhost:3000/socialLogin/google/callback"
            },
                function (accessToken, refreshToken, profile, done) {
                    userProfile = profile;
                    return done(null, userProfile);
                }
            ));
            app.get('/socialLogin/google',
                passport.authenticate('google', { scope: ['profile', 'email'] }));

            app.get('/auth/google/callback',
                passport.authenticate('google', { failureRedirect: '/error' }),
                function (req, res) {
                    // Successful authentication, redirect success.
                    res.redirect('/success');
                });

        } catch (error) {
            return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ msg: err.message })
        }
    },
    linkedInLogin: async () => {
        try {

        } catch (error) {
            return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ msg: err.message })
        }
    }
}
module.exports = socialLoginController