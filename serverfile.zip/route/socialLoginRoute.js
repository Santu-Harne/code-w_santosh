const route = require('express').Router()
const { StatusCodes } = require("http-status-codes")
const passport = require("passport")

const CLIENT_URL = "http://localhost:3000"
const LOGIN_URL = "http://localhost:3000/socialLoginAuth/login/success"

route.get("login/failed", (req, res) => {
    res.status(StatusCodes.BAD_REQUEST).json({
        success: false,
        msg: "Failed to Login"
    })
})


route.get("login/success", (req, res) => {
    if (req.user) {
        res.status(StatusCodes.OK).json({
            success: true,
            msg: "Authenticated Successfully and Logged In",
            user: req.user
            // cookies: req.cookies
        })
    }
})

route.get("/logout", (req, res) => {
    // res.clearCookie("session", { path: '/socialAuth/login/success' })
    req.logout();
    res.redirect(CLIENT_URL)
})

route.get('/login', passport.authenticate("google", { scope: ["profile", "email"] }))
route.get('login/callback', passport.authenticate('google', {
    successRedirect: LOGIN_URL,
    failureRedirect: "/login/failed"
}))
// route.get('/linkedIn', socialLoginController.linkedInLogin)

module.exports = route