import React, { useState, useEffect } from "react"
import "bootstrap/dist/css/bootstrap.min.css"
import '../formStyles/App.css'
import axios from "axios"
import { NavLink, useNavigate } from "react-router-dom"
import { toast } from 'react-toastify';


const initialState = {
  Email: "",
  Password: ""
}

function Login() {

  const [show, setShow] = useState(false)

  const showHide = () => {
    setShow(!show)
  }
  const navigate = useNavigate()

  const [data, setData] = useState(initialState)

  const readValue = (e) => {
    e.preventDefault()
    const { name, value } = e.target
    setData({ ...data, [name]: value })
  }

  const submitHandler = async (e) => {
    e.preventDefault()
    try {
      await axios.post('/auth/login', data)
        .then(res => {
          // console.log("after login =", res.data)
          toast.success(res.data.msg)
          setData(initialState)
          if (res.data.msg === "Login Successful") {
            navigate('/auth/userProfile')
          }
        }).catch(err => toast.error(err.response.data.msg))
    } catch (error) {
      console.log(error.message);
    }
  }

  useEffect(() => {
    // console.log(data)
  }, [data])

  const googleLogin = async (e) => {
    window.open("http://localhost:7000/socialLoginAuth/login", "_self")
  }

  return (
<div className="Auth-form-container bg-primary" style={{backgroundImage:"url(https://wallup.net/wp-content/uploads/2016/03/10/321535-photography-landscape-nature-night-field-trees.jpg)",backgroundRepeat:"no-repeat",backgroundSize:"cover"}}>
      <form className="Auth-form bg-info pb-5" autoComplete="off" >
        <div className="Auth-form-content ">
          <p className="Auth-form-title text-dark">Login</p>

          <div className="form-group mt-3">
            <label>Email :</label>
            <input type="email" className="form-control mt-1" name="Email" value={data.Email} onChange={readValue} placeholder="Enter email" />
          </div>
          <div className="form-group mt-3">
            <label>Password :</label>
            <input type="password" className="form-control mt-1" name="Password" value={data.Password} onChange={readValue} placeholder="Enter password" />
            <NavLink to={'/auth/forgotPassword'} className="float-end mt-2 text-dark ">Forgot Password</NavLink>
          </div>

          <div className="gap-2 mt-3">
            <button type="submit" onClick={(e) => submitHandler(e)} className="btn btn-success">
              Submit
            </button>
          </div>
          <hr />
          <div className="row  ">
            <div className="d-grid col-md-12 gap-3 ">
              {/* <button className="btn btn-outline-primary form-control" onClick={googleLogin}><i className="bi bi-google me-4" ></i>Sign in with google</button> */}
              {/* <i className="bi bi-google me-4 btn btn-outline-primary form-control" onClick={googleLogin}>Sign in with google</i> */}
              {/* <button className="btn btn-outline-primary form-control" ><i className="bi bi-linkedin me-4"></i>Sign in with LinkedIn</button>
              <button className="btn btn-outline-primary form-control"><i className="bi bi-stripe me-4"></i>Sign in with Code S</button> */}
            </div>
            <div className="d-grid col-md-12 gap-3 pt-3 ">
          <button className="btn btn-outline-dark form-control" onClick={googleLogin}><i className="bi bi-google me-4"></i>Sign in with google</button>
          <button className="btn btn-outline-dark form-control" onClick={()=>{navigate("/linkedIn")}}><i className="bi bi-linkedin me-4"></i>Sign in with LinkedIn</button>
          <button className="btn btn-outline-dark form-control" onClick={()=>{navigate("/Code S")}}><i className="bi bi-stripe me-4 "></i>Sign in with Code S</button>
          </div>
          </div>
        </div>
      </form>
    </div>
  )
}

export default Login